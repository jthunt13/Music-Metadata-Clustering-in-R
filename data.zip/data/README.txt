    Author      :  Joseph Hadley  
Date Created    :   2018-04-01    
Date Modified   :   2018-04-06    
----------------------------------------------------

To Setup the database:

1: Create a database named "sta546" in mysql.
2: download the FMA data 
    (https://github.com/mdeff/fma and then click on
    the fma_metadata.zip hyperlink) and drop the 
    features csv into the data folder.
2: Go to data directory (from command line)
3: run "cat sqlScripts/*.sql | mysql -u root -p".
