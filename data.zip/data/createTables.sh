user="root"
password="Hadleyj1"

for FILE in ./sqlScripts/*.sql; do 
	mysql -u$user -p$password < $FILE;
	echo $FILE;
done
