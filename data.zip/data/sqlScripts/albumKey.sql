use sta546;

DROP TABLE IF EXISTS album_key;

CREATE TABLE album_key (
album_id INT NOT NULL PRIMARY KEY,
album_date_released DATE DEFAULT NULL,
album_tracks TINYINT DEFAULT NULL,
album_type VARCHAR(20) DEFAULT NULL
);

LOAD DATA LOCAL INFILE 'album_key.csv' INTO TABLE album_key FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' IGNORE 1 LINES(
album_id,
album_date_released,
album_tracks,
album_type
);
