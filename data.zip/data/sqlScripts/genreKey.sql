use sta546;

DROP TABLE IF EXISTS genre_key;

CREATE TABLE genre_key (
genre_id SMALLINT NOT NULL PRIMARY KEY,
parent SMALLINT DEFAULT NULL, 
title VARCHAR(24) DEFAULT NULL,
top_level_parent SMALLINT DEFAULT NULL
);

LOAD DATA LOCAL INFILE 'genre_key.csv' INTO TABLE genre_key FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' IGNORE 1 LINES(
genre_id,
parent,
title,
top_level_parent
);
