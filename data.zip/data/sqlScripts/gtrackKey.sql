use sta546;

DROP TABLE IF EXISTS track_key;

CREATE TABLE track_key (
track_id INT NOT NULL,
album_id INT DEFAULT NULL,
artist_id INT DEFAULT NULL,
genre_id INT DEFAULT NULL,
PRIMARY KEY (track_id),
KEY(genre_id)
);

LOAD DATA LOCAL INFILE 'track_key.csv' INTO TABLE track_key FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' IGNORE 1 LINES(
track_id,
album_id,
artist_id,
genre_id
);
